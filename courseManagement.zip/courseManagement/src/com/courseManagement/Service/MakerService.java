package com.courseManagement.Service;

import java.util.List;

import com.courseManagement.hibernate.Course;
import com.courseManagement.hibernate.Experiment;
import com.courseManagement.hibernate.Maker;

public interface MakerService {
	//��½
	Maker makerLogin(String name);
	//���ҿγ�		
	List<Course> selectCourseBymaekrId(int makerId);
	//ע��
	void makerReg(Maker maker);
	//����ʵ����Ϣ	
	void addExpermentInfo(Experiment experiment);
	//���ҿγ�	
	Course selectCourseByCourseId(int courseId1);
	//���²���
	void updateE(Experiment experiment);

	

}
