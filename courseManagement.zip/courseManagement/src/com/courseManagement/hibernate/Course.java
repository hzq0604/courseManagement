package com.courseManagement.hibernate;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


@Entity
@Table(name="course")
public class Course {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="courseId")
	private int courseId;
	private String cTitle;
	private String cIntroduce;
	private String makerName;
	private String  time;
	private String State;
		//@OneToManyӳ���ϵ
		//CascadeTypeΪ�������ԣ�ALL��ʾȫ����������������ɾ���ȣ�
		//@JoinColumΪ��Ӧ�Ķ��һ������
		
		@OneToMany(targetEntity=Experiment.class,orphanRemoval=true)
		@Cascade(value={CascadeType.ALL})
		@JoinColumn(name="courseId")	
		private Set<Experiment> e = new HashSet<>();
	
	public Set<Experiment> getE() {
			return e;
		}
		public void setE(Set<Experiment> e) {
			this.e = e;
		}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getcTitle() {
		return cTitle;
	}
	public void setcTitle(String cTitle) {
		this.cTitle = cTitle;
	}
	public String getcIntroduce() {
		return cIntroduce;
	}
	public void setcIntroduce(String cIntroduce) {
		this.cIntroduce = cIntroduce;
	}
	public String getMakerName() {
		return makerName;
	}
	public void setMakerName(String makerName) {
		this.makerName = makerName;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	
	
	
}
