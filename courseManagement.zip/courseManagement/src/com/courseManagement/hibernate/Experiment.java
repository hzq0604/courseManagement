package com.courseManagement.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


@Entity
@Table(name="experiment")
public class Experiment {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="experimentId")
	private int experimentId;//����
	private String eTitle;//ʵ�����
	private String eIntroduce;//ʵ����
	private String time;//ʵ������ʱ�䣨����ΪString��ԭ���ǻ�����ڽ��и�ʽת����
	/*
	 * @ManyToOne���һ
	 * @JoinColum�У�
	 * name��ʾ�ڱ����е����������
	 * referencedColumnName��ʾ������������
	 * 
	 */
	@ManyToOne
	@JoinColumn(name="courseId",referencedColumnName = "courseId")
	private Course courseId;
	public int getExperimentId() {
		return experimentId;
	}
	public void setExperimentId(int experimentId) {
		this.experimentId = experimentId;
	}
	public String geteTitle() {
		return eTitle;
	}
	public void seteTitle(String eTitle) {
		this.eTitle = eTitle;
	}
	public String geteIntroduce() {
		return eIntroduce;
	}
	public void seteIntroduce(String eIntroduce) {
		this.eIntroduce = eIntroduce;
	}
	public Course getCourseId() {
		return courseId;
	}
	public void setCourseId(Course courseId) {
		this.courseId = courseId;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
}
